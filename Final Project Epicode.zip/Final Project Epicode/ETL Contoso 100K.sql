-- In this query page we do the ETL process
-- We could use the power query editor of Power BI, but for didactic purposes I execute this procedure with SQL SERVER

select	CustomerKey,
		Gender,
		GivenName + ' ' + Surname			as FullName,
		CAST(Birthday as date)		as Birthday,
		Occupation,
		Company,
		City,
		StateFull,
		CountryFull,
		Continent,
		Latitude,
		Longitude
from	Data.Customer

--

select	StoreKey,
		Name						as StoreName,
		Country,
		State,
		CAST([Open Date] as date)	as OpenDate,
		CAST([Close Date] as date)	as CloseDate,
		Status
from	Data.Store

--

select	ProductKey,
		[Product Name],
		Manufacturer,
		[Unit Cost]					as	Cost,
		[Unit Price]				as	SellingPrice,
		[Unit Price]-[Unit Cost]	as	Profit,
		Subcategory,
		Category
from	Data.Product

--

select	o.OrderKey,
		CustomerKey,
		StoreKey,
		r.ProductKey,
		r.Quantity,
		r.[Unit Cost],
		r.Quantity * r.[Unit Cost]	as	OrderCost,
		[Order Date],
		[Delivery Date],
		DATEDIFF(day, [Order Date], [Delivery Date]) AS DeliveryDayTime
from Data.Orders			as o
Left Join Data.OrderRows	as r
on o.OrderKey = r.OrderKey
